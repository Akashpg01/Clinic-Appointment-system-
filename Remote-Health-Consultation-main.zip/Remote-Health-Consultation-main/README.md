<h1>Remote Health Consultaion System</h1>
<p>It is Doctor Appointment Booking application created by using MERN technology. It is simple and easy to use </p>
<br>
<br>
<h1>M E R N  Stack</h1>
<h3>Techonologies Used in the Project:</h3>
<li>Mongo DB</li>
<li>Express.js</li>
<li>React.js</li>
<li>Node.js(for backend)</li>



<h3> How to run the project :</h3>
<br>
<ol>Create .env file in root directory and add the following things :</ol>
<br>
<p>PORT=" Please enter a valid port number 8080"</p>
<p>MONGO_URL="Your MONGO_URI"</p>
<p>NODE_MODE="devlopemnet"</p>
<p>JWT_SECRET="your jwt secret"</p>
 <br>
 <br>
 <h2>Installing the required dependencies :</h2>
 <br>
 <ol><li>In the root directory : "npm install" </li>
 <li>cd client  : "npm install "</li>
 <li><p> To start the frontend  : "npm start"</li>
 <li>To start the backend and frontend Concurrently Use : "npm run dev"</li></ol>
 <br>
 <br>
<h2>Project Team Members :</h2>
<ol><li>Keshav Kolekar</li>
<li>Ashish Kolekar</li>
<li>shivraj kachare</li>
<li>Prathamesh Dhembare</li></ol>
<br>
<hr>
<p> Connect with me on LinkedIn: www.linkedin.com/in/keshav-kolekar-9058a0279</p>
